<?php
/**
* 2015 emotionLoop
*
* NOTE
* You are free edit and play around with the module.
* Please visit contentbox.org for more information.
*
*  @author    Miguel Costa for emotionLoop
*  @copyright emotionLoop
*  @version   1.1.1
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  http://emotionloop.com
*  http://contentbox.org/
*/

if (!defined( '_PS_VERSION_' ))
	exit;



class WEBSITESPEED extends Module
{
	public function __construct()
	{
		$this->name = 'websitespeed';
		$this->description = 'Your website speed in dashboard';
		$this->tab = 'front_office_features';
		$this->version = '1.1.1';
		$this->author = 'cWebco India';
		$this->need_instance = 0;
		$this->ps_versions_compliancy = array('min' => '1.5', 'max' => _PS_VERSION_);
	
		$this->bootstrap = true;
		$this->_html = '';		
		$this->apikey = 'websitespeed_APIKEY';
		parent::__construct();

		$this->displayName = $this->l('Website speed');
		$this->description = $this->l('Your website speed in dashboard');

		$this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

		
	}

	public function install()
	{
		if (Shop::isFeatureActive())
			Shop::setContext(Shop::CONTEXT_ALL);

		if (!parent::install() || !$this->registerHook('header') || !$this->registerHook('displayBackOfficeHome') || !$this->registerHook('footer') || !$this->registerHook('dashboardZoneOne') || !$this->registerHook('dashboardZoneTwo')  || !$this->registerHook('dashboardZoneThree')  || !$this->registerHook('dashboardData'))
			return false;

		

		$this->_clearCache('template.tpl');

		return true;
	}

	public function uninstall()
	{
		$this->_clearCache('template.tpl');
		if (!parent::uninstall())
		{

			return false;
		}
		return true;
	}

	public function __call($method, $args)
	{
		//if method exists
		if (function_exists($method))
			return call_user_func_array($method, $args);

		//if head hook: add the css and js files
		if ($method == 'hookdisplayHeader')
			return $this->hookHeader( $args[0] );

		//check for a call to an hook
		if (strpos($method, 'hook') !== false)
			return $this->genericHookMethod( $args[0] );

	}

	

	public function hookHeader()
	{
		$this->addFilesToTemplate( $this->_path.'content/' );
	}
        
        
        
        public function hookDashboardZoneTwo($params)
        {
            
           return $this->displayForm();
            
            
        }
        
       public function hookDashboardZoneOne($params)
        {
            
           //return $this->displayForm();
            
        }
        public function hookDashboardZoneThree($params)
        {
            
          return $this->displayForm();
            
        }
        
	public function hookdisplayBackOfficeHome($permes)
	{
         
	}

	public function getContent()
	{
		$this->processSubmit();
		return $this->displayForm();
	}

	public function processSubmit()
	{
			
			//store the developer configurations
			if (Tools::getIsset('apikey'))
				Configuration::updateValue($this->apikey,Tools::getValue('apikey'));

		}

        
      public function checkPageSpeed($url) {
        if (function_exists('file_get_contents')) {
            $result = @file_get_contents($url);
        }
        if ($result == '') {
            $ch = curl_init();
            $timeout = 60;
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            $result = curl_exec($ch);
            curl_close($ch);
        }

        return $result;
    }
    
        public function formatSizeUnits($bytes) {
            if ($bytes >= 1073741824) {
                $bytes = number_format($bytes / 1073741824, 2) . ' GB';
            } elseif ($bytes >= 1048576) {
                $bytes = number_format($bytes / 1048576, 2) . ' MB';
            } elseif ($bytes >= 1024) {
                $bytes = number_format($bytes / 1024, 2) . ' kB';
            } elseif ($bytes > 1) {
                $bytes = $bytes . ' bytes';
            } elseif ($bytes == 1) {
                $bytes = $bytes . ' byte';
            } else {
                $bytes = '0 bytes';
            }

            return $bytes;
        }

	public function displayForm()
	{
		$default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
                $url = _PS_BASE_URL_ . __PS_BASE_URI__;
		$link = $this->context->link;
              
		$fields_form = array();
		$fields_form[]['form'] = array(
				'input' => array(
					array(
						'name' => 'topform',
						'type' => 'topform',						
						'moduleName' => $this->displayName,
						'moduleDescription' => $this->description,
						'apikey' =>Configuration::get($this->apikey) ,
						'getmodule' => $link->getAdminLink("AdminModules"),
						'moduleVersion' => $this->version,						
						'site_url' => $url,
					),
				),
			);
		
		$helper = new HelperForm();

		
		$helper->module = $this;
		$helper->name_controller = $this->name;
		
		return $this->_html.$helper->generateForm($fields_form);
	}


}
