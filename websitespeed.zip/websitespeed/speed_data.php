<?php

require_once(dirname(__FILE__) . '../../../config/config.inc.php');
require_once(dirname(__FILE__) . '../../../init.php');
include(dirname(__FILE__) . '/websitespeed.php');

$my_module = new WEBSITESPEED();

       // $url = "http://188.166.238.255/project/";
        $url = _PS_BASE_URL_ . __PS_BASE_URI__;


        if (!empty((Configuration::get("websitespeed_APIKEY")))){
		
	$myKEY = Configuration::get("websitespeed_APIKEY");
	}else{
		$myKEY = "AIzaSyAsAD56f-gh0C7v2Fg2KnAPeQRGb9kD_9I";
	}   


$url_req = 'https://www.googleapis.com/pagespeedonline/v1/runPagespeed?url=' . $url . '&screenshot=true&key=' . $myKEY;
        $sitespeed = $my_module->checkPageSpeed($url_req);
        $sitespeed_res = json_decode($sitespeed, true);

        $load_total_data = $my_module->formatSizeUnits($sitespeed_res['pageStats']['totalRequestBytes']);




        $mobilepage_speed = "https://www.googleapis.com/pagespeedonline/v3beta1/runPagespeed?key=" . $myKEY . "&screenshot=true&snapshots=true&locale=en_US&url=" . $url . "&strategy=mobile";
        $sitespeed_m = $my_module->checkPageSpeed($mobilepage_speed);
        $sitespeed_res_m = json_decode($sitespeed_m, true);
        $load_total_data_mobile = $sitespeed_res_m['ruleGroups']['SPEED']['score'];



        if (isset($sitespeed_res['score'])) {
         $speed = $sitespeed_res['score'];
        } else {
        $speed = 0;
        }

        if (isset($load_total_data_mobile)) {
        $mobile = $load_total_data_mobile;
        } else {
        $mobile = 0;
        }

    echo "<div class='website_speed_m'>";
    echo "<div class='website_speed_mb'>";
    echo "Mobile<br>";
    echo "<samp>";
   echo $mobile;
    echo "</samp>/100%";
     echo "</div>";
    echo "</div>";
    
    
    echo "<div class='website_speed_d'>";
     echo "<div class='website_speed_de'>";
    echo "Desktop<br>";
    echo "<samp>";
    echo $speed;
    
    echo "</samp>/100%";
    echo "</div>";
    echo "</div>";

  
    if($mobile < 80 || $speed < 80){
       echo   "<p class='developer_website'> Need developers to fix speed? <a href='http://www.cwebconsultants.com/' class='' target='_blank' >   click here. </a></p>";
    }

?>
